"use client";

import type { Metadata } from "next";
import { useMemo } from "react";
import { ConnectionProvider, WalletProvider } from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-phantom";
import { SolflareWalletAdapter } from "@solana/wallet-adapter-solflare";
import { RPC_ENDPOINT } from "@/lib/constants";
import "@solana/wallet-adapter-react-ui/styles.css";
import "./globals.css";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const wallets = useMemo(
    () => [new PhantomWalletAdapter(), new SolflareWalletAdapter()],
    []
  );

  return (
    <html lang="es">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-quorum-bg text-quorum-text font-body antialiased">
        <ConnectionProvider endpoint={RPC_ENDPOINT}>
          <WalletProvider wallets={wallets} autoConnect>
            <WalletModalProvider>
              <Nav />
              <main className="min-h-screen">{children}</main>
              <Footer />
            </WalletModalProvider>
          </WalletProvider>
        </ConnectionProvider>
      </body>
    </html>
  );
}

function Nav() {
  return (
    <nav className="border-b border-quorum-border bg-quorum-surface/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <a href="/" className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-quorum-green flex items-center justify-center">
            <span className="text-quorum-bg font-display font-bold text-sm">Q</span>
          </div>
          <span className="font-display text-lg text-quorum-text tracking-tight">
            QUORUM
          </span>
          <span className="text-xs text-quorum-muted font-display bg-quorum-border px-2 py-0.5 rounded">
            devnet
          </span>
        </a>

        <div className="flex items-center gap-6">
          <a href="/" className="text-sm text-quorum-muted hover:text-quorum-text transition-colors">
            Proyectos
          </a>
          <a href="/launch" className="text-sm text-quorum-muted hover:text-quorum-text transition-colors">
            Lanzar
          </a>
          <WalletButton />
        </div>
      </div>
    </nav>
  );
}

function WalletButton() {
  // Wrapper lazy para evitar SSR issues con wallet adapter
  const { WalletMultiButton } = require("@solana/wallet-adapter-react-ui");
  return (
    <WalletMultiButton
      style={{
        backgroundColor: "transparent",
        border: "1px solid #1E2A38",
        borderRadius: "8px",
        color: "#E2EBF4",
        fontSize: "13px",
        height: "36px",
        fontFamily: "'DM Mono', monospace",
      }}
    />
  );
}

function Footer() {
  return (
    <footer className="border-t border-quorum-border mt-24 py-12">
      <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 rounded bg-quorum-green flex items-center justify-center">
            <span className="text-quorum-bg font-display font-bold text-xs">Q</span>
          </div>
          <span className="font-display text-sm text-quorum-muted">QUORUM PROTOCOL</span>
        </div>
        <p className="text-xs text-quorum-muted font-display">
          Tokens con intención. Comunidad como filtro.
        </p>
      </div>
    </footer>
  );
}
