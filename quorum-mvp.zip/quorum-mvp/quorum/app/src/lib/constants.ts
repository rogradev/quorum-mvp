import { PublicKey } from "@solana/web3.js";

// ── Programa ──────────────────────────────────────────────────
export const PROGRAM_ID = new PublicKey(
  "Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS"
);

// ── Seeds PDA ─────────────────────────────────────────────────
export const PLATFORM_SEED = Buffer.from("platform");
export const PROJECT_SEED = Buffer.from("project");
export const CONTRIBUTION_SEED = Buffer.from("contribution");
export const VOTE_SEED = Buffer.from("vote");
export const VAULT_SEED = Buffer.from("vault");

// ── Parámetros del protocolo ──────────────────────────────────
export const PLATFORM_FEE_BPS = 10; // 0.1%
export const MAX_HOLDER_BPS = 10; // 0.1% del supply
export const MIN_HOLDERS = 1_000;
export const TOKEN_SUPPLY = 1_000_000_000_000_000n; // 1B × 10^6
export const TOKEN_DECIMALS = 6;

// Tiempos (ms para frontend)
export const SOCIAL_VOTE_DURATION_MS = 7 * 24 * 60 * 60 * 1000;
export const ECONOMIC_PHASE_DURATION_MS = 14 * 24 * 60 * 60 * 1000;
export const VESTING_DURATION_MS = 270 * 24 * 60 * 60 * 1000;

// ── Red ───────────────────────────────────────────────────────
export const RPC_ENDPOINT =
  process.env.NEXT_PUBLIC_RPC_ENDPOINT || "https://api.devnet.solana.com";

// ── Display helpers ───────────────────────────────────────────
export const LAMPORTS_PER_SOL = 1_000_000_000;

// Precio aproximado de SOL en USD (actualizar o usar oráculo en producción)
export const SOL_PRICE_USD = 150;

export function lamportsToUsd(lamports: bigint | number): number {
  const sol = Number(lamports) / LAMPORTS_PER_SOL;
  return sol * SOL_PRICE_USD;
}

export function lamportsToSol(lamports: bigint | number): number {
  return Number(lamports) / LAMPORTS_PER_SOL;
}

export function formatUsd(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatNumber(n: number | bigint): string {
  return new Intl.NumberFormat("en-US").format(Number(n));
}

export function shortenAddress(address: string, chars = 4): string {
  return `${address.slice(0, chars)}...${address.slice(-chars)}`;
}

export function timeRemaining(deadline: Date): string {
  const diff = deadline.getTime() - Date.now();
  if (diff <= 0) return "Terminado";
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  if (days > 0) return `${days}d ${hours}h`;
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${mins}m`;
}

export const PROJECT_STATE_LABELS: Record<string, string> = {
  SOCIAL_VOTING: "Votación Social",
  ECONOMIC_PHASE: "Fase Económica",
  VESTING: "Vesting Activo",
  FAILED: "Fallido",
  GRADUATED: "Graduado",
};

export const PROJECT_STATE_COLORS: Record<string, string> = {
  SOCIAL_VOTING: "text-quorum-amber border-quorum-amber bg-quorum-amber-dim",
  ECONOMIC_PHASE: "text-blue-400 border-blue-400 bg-blue-400/10",
  VESTING: "text-quorum-green border-quorum-green bg-quorum-green-dim",
  FAILED: "text-quorum-red border-quorum-red bg-quorum-red-dim",
  GRADUATED: "text-purple-400 border-purple-400 bg-purple-400/10",
};
