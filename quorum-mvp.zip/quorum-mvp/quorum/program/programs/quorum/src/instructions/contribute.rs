use anchor_lang::prelude::*;
use anchor_lang::system_program;
use crate::state::{Platform, Project, ProjectState, Contribution};
use crate::constants::*;
use crate::errors::QuorumError;

/// Contribución económica en Fase 2.
/// Cobra el 0.1% de fee a la plataforma inmediatamente.
/// Respeta el límite de 0.1% del supply por holder.
pub fn handler(ctx: Context<Contribute>, amount_lamports: u64) -> Result<()> {
    let project = &mut ctx.accounts.project;
    let platform = &mut ctx.accounts.platform;
    let now = Clock::get()?.unix_timestamp;

    // ── Validaciones de estado ──────────────────────────────
    require!(
        project.state == ProjectState::EconomicPhase,
        QuorumError::EconomicPhaseNotActive
    );

    let phase_deadline = project
        .economic_phase_start
        .checked_add(ECONOMIC_PHASE_DURATION_SECS)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    require!(now <= phase_deadline, QuorumError::EconomicPhaseNotActive);

    // Mínimo $1 USD equiv. en lamports (~6_666_667 lamports @ SOL $150)
    let min_contribution: u64 = MIN_RAISE_LAMPORTS / 100;
    require!(amount_lamports >= min_contribution, QuorumError::ContributionTooLow);

    // ── Calcular tokens a asignar ───────────────────────────
    // Los tokens se distribuyen proporcionalmente al aporte sobre la meta
    // TOKEN_SUPPLY × (amount / raise_goal) con límite de 0.1%
    let tokens_for_amount = (amount_lamports as u128)
        .checked_mul(TOKEN_SUPPLY as u128)
        .ok_or(QuorumError::ArithmeticOverflow)?
        .checked_div(project.raise_goal as u128)
        .ok_or(QuorumError::ArithmeticOverflow)? as u64;

    // Límite: 0.1% del supply = TOKEN_SUPPLY * 10 / 10000
    let max_tokens_per_holder = TOKEN_SUPPLY
        .checked_mul(MAX_HOLDER_BPS)
        .ok_or(QuorumError::ArithmeticOverflow)?
        .checked_div(10_000)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    // Tokens ya asignados a este holder + nuevos
    let existing_tokens = ctx.accounts.contribution.tokens_allocated;
    let new_total_tokens = existing_tokens
        .checked_add(tokens_for_amount)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    require!(
        new_total_tokens <= max_tokens_per_holder,
        QuorumError::ExceedsHolderLimit
    );

    // ── Cobrar fee de plataforma ────────────────────────────
    // 0.1% = amount * PLATFORM_FEE_BPS / 10_000
    let platform_fee = amount_lamports
        .checked_mul(PLATFORM_FEE_BPS)
        .ok_or(QuorumError::ArithmeticOverflow)?
        .checked_div(10_000)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    let net_contribution = amount_lamports
        .checked_sub(platform_fee)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    // Transferir fee a tesorería de la plataforma
    system_program::transfer(
        CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            system_program::Transfer {
                from: ctx.accounts.contributor.to_account_info(),
                to: ctx.accounts.treasury.to_account_info(),
            },
        ),
        platform_fee,
    )?;

    // Transferir contribución neta al vault del proyecto
    system_program::transfer(
        CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            system_program::Transfer {
                from: ctx.accounts.contributor.to_account_info(),
                to: ctx.accounts.project_vault.to_account_info(),
            },
        ),
        net_contribution,
    )?;

    // ── Actualizar estado ───────────────────────────────────
    let contribution = &mut ctx.accounts.contribution;
    let is_new_holder = contribution.amount_lamports == 0;

    contribution.project_id = project.project_id;
    contribution.contributor = ctx.accounts.contributor.key();
    contribution.amount_lamports = contribution
        .amount_lamports
        .checked_add(net_contribution)
        .ok_or(QuorumError::ArithmeticOverflow)?;
    contribution.tokens_allocated = new_total_tokens;
    contribution.claimed = false;
    contribution.refunded = false;
    contribution.contributed_at = now;
    contribution.bump = ctx.bumps.contribution;

    project.total_raised = project
        .total_raised
        .checked_add(net_contribution)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    project.platform_fee_paid = project
        .platform_fee_paid
        .checked_add(platform_fee)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    if is_new_holder {
        project.holder_count = project
            .holder_count
            .checked_add(1)
            .ok_or(QuorumError::ArithmeticOverflow)?;
    }

    platform.total_fees_collected = platform
        .total_fees_collected
        .checked_add(platform_fee)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    emit!(ContributionMade {
        project_id: project.project_id,
        contributor: ctx.accounts.contributor.key(),
        amount_lamports: net_contribution,
        tokens_allocated: new_total_tokens,
        total_raised: project.total_raised,
        holder_count: project.holder_count,
    });

    Ok(())
}

#[derive(Accounts)]
#[instruction(amount_lamports: u64)]
pub struct Contribute<'info> {
    #[account(
        mut,
        seeds = [PLATFORM_SEED],
        bump = platform.bump
    )]
    pub platform: Account<'info, Platform>,

    #[account(
        mut,
        seeds = [PROJECT_SEED, &project.project_id.to_le_bytes()],
        bump = project.bump
    )]
    pub project: Account<'info, Project>,

    #[account(
        init_if_needed,
        payer = contributor,
        space = 8 + Contribution::INIT_SPACE,
        seeds = [CONTRIBUTION_SEED, &project.project_id.to_le_bytes(), contributor.key().as_ref()],
        bump
    )]
    pub contribution: Account<'info, Contribution>,

    /// CHECK: Vault del proyecto — PDA sin data que recibe SOL
    #[account(
        mut,
        seeds = [b"vault", &project.project_id.to_le_bytes()],
        bump
    )]
    pub project_vault: UncheckedAccount<'info>,

    /// CHECK: Tesorería de la plataforma
    #[account(
        mut,
        constraint = treasury.key() == platform.treasury
    )]
    pub treasury: UncheckedAccount<'info>,

    #[account(mut)]
    pub contributor: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[event]
pub struct ContributionMade {
    pub project_id: u64,
    pub contributor: Pubkey,
    pub amount_lamports: u64,
    pub tokens_allocated: u64,
    pub total_raised: u64,
    pub holder_count: u64,
}
