use anchor_lang::prelude::*;
use crate::state::{Project, ProjectState, SocialVote};
use crate::constants::*;
use crate::errors::QuorumError;

/// Cualquier wallet vota en la fase social.
/// Sin requisitos económicos — es una señal de interés.
pub fn handler(ctx: Context<CastSocialVote>) -> Result<()> {
    let project = &mut ctx.accounts.project;
    let now = Clock::get()?.unix_timestamp;

    // Verificar que la fase social esté activa
    require!(
        project.state == ProjectState::SocialVoting,
        QuorumError::SocialVoteNotActive
    );

    // Verificar que no haya expirado
    let vote_deadline = project
        .social_vote_start
        .checked_add(SOCIAL_VOTE_DURATION_SECS)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    require!(now <= vote_deadline, QuorumError::SocialVoteNotActive);

    // Registrar el voto
    let vote = &mut ctx.accounts.social_vote;
    vote.project_id = project.project_id;
    vote.voter = ctx.accounts.voter.key();
    vote.voted_at = now;
    vote.bump = ctx.bumps.social_vote;

    project.social_votes = project
        .social_votes
        .checked_add(1)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    emit!(SocialVoteCast {
        project_id: project.project_id,
        voter: ctx.accounts.voter.key(),
        total_votes: project.social_votes,
    });

    Ok(())
}

/// Transiciona de Fase 1 a Fase 2 una vez que terminó la votación social.
/// Cualquiera puede llamar esto para activar la fase económica.
pub fn advance_to_economic(ctx: Context<AdvanceToEconomic>) -> Result<()> {
    let project = &mut ctx.accounts.project;
    let now = Clock::get()?.unix_timestamp;

    require!(
        project.state == ProjectState::SocialVoting,
        QuorumError::SocialVoteNotActive
    );

    let vote_deadline = project
        .social_vote_start
        .checked_add(SOCIAL_VOTE_DURATION_SECS)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    require!(now > vote_deadline, QuorumError::SocialVoteNotEnded);

    project.state = ProjectState::EconomicPhase;
    project.economic_phase_start = now;

    emit!(EconomicPhaseStarted {
        project_id: project.project_id,
        social_votes: project.social_votes,
        started_at: now,
    });

    Ok(())
}

#[derive(Accounts)]
pub struct CastSocialVote<'info> {
    #[account(
        mut,
        seeds = [PROJECT_SEED, &project.project_id.to_le_bytes()],
        bump = project.bump
    )]
    pub project: Account<'info, Project>,

    #[account(
        init,
        payer = voter,
        space = 8 + SocialVote::INIT_SPACE,
        seeds = [VOTE_SEED, &project.project_id.to_le_bytes(), voter.key().as_ref()],
        bump
    )]
    pub social_vote: Account<'info, SocialVote>,

    #[account(mut)]
    pub voter: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AdvanceToEconomic<'info> {
    #[account(
        mut,
        seeds = [PROJECT_SEED, &project.project_id.to_le_bytes()],
        bump = project.bump
    )]
    pub project: Account<'info, Project>,

    pub caller: Signer<'info>,
}

#[event]
pub struct SocialVoteCast {
    pub project_id: u64,
    pub voter: Pubkey,
    pub total_votes: u64,
}

#[event]
pub struct EconomicPhaseStarted {
    pub project_id: u64,
    pub social_votes: u64,
    pub started_at: i64,
}
