use anchor_lang::prelude::*;
use crate::state::{Project, ProjectState};
use crate::constants::*;
use crate::errors::QuorumError;

/// Finaliza la fase de fondeo una vez que terminó el período económico.
/// Si se cumplieron los requisitos → inicia vesting.
/// Si no → marca como fallido para reembolsos.
pub fn handler(ctx: Context<FinalizeFunding>) -> Result<()> {
    let project = &mut ctx.accounts.project;
    let now = Clock::get()?.unix_timestamp;

    require!(
        project.state == ProjectState::EconomicPhase,
        QuorumError::InvalidProjectState
    );

    let phase_deadline = project
        .economic_phase_start
        .checked_add(ECONOMIC_PHASE_DURATION_SECS)
        .ok_or(QuorumError::ArithmeticOverflow)?;

    require!(now > phase_deadline, QuorumError::EconomicPhaseNotEnded);

    // Verificar si cumple con los requisitos mínimos
    let holders_ok = project.holder_count >= MIN_HOLDERS;
    let funds_ok = project.total_raised >= project.raise_goal;

    if holders_ok && funds_ok {
        // ✅ Proyecto exitoso — iniciar vesting
        project.state = ProjectState::Vesting;
        project.vesting_start = now;
        project.vesting_end = now
            .checked_add(VESTING_DURATION_SECS)
            .ok_or(QuorumError::ArithmeticOverflow)?;

        emit!(FundingSucceeded {
            project_id: project.project_id,
            total_raised: project.total_raised,
            holder_count: project.holder_count,
            vesting_end: project.vesting_end,
        });
    } else {
        // ❌ Proyecto fallido — disponible para reembolsos
        project.state = ProjectState::Failed;

        emit!(FundingFailed {
            project_id: project.project_id,
            total_raised: project.total_raised,
            holder_count: project.holder_count,
            holders_ok,
            funds_ok,
        });
    }

    Ok(())
}

#[derive(Accounts)]
pub struct FinalizeFunding<'info> {
    #[account(
        mut,
        seeds = [PROJECT_SEED, &project.project_id.to_le_bytes()],
        bump = project.bump
    )]
    pub project: Account<'info, Project>,

    /// Cualquiera puede llamar esto — permissionless
    pub caller: Signer<'info>,
}

#[event]
pub struct FundingSucceeded {
    pub project_id: u64,
    pub total_raised: u64,
    pub holder_count: u64,
    pub vesting_end: i64,
}

#[event]
pub struct FundingFailed {
    pub project_id: u64,
    pub total_raised: u64,
    pub holder_count: u64,
    pub holders_ok: bool,
    pub funds_ok: bool,
}
