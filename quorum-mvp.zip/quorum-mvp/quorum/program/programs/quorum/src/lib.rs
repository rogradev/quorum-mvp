use anchor_lang::prelude::*;

pub mod constants;
pub mod errors;
pub mod state;
pub mod instructions;

use instructions::*;
use create_project::CreateProjectParams;

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

#[program]
pub mod quorum {
    use super::*;

    // ── Administración de plataforma ──────────────────────────
    pub fn initialize_platform(ctx: Context<initialize_platform::InitializePlatform>) -> Result<()> {
        initialize_platform::handler(ctx)
    }

    // ── Ciclo de vida del proyecto ────────────────────────────
    pub fn create_project(
        ctx: Context<create_project::CreateProject>,
        params: CreateProjectParams,
    ) -> Result<()> {
        create_project::handler(ctx, params)
    }

    pub fn cast_social_vote(ctx: Context<social_vote::CastSocialVote>) -> Result<()> {
        social_vote::handler(ctx)
    }

    pub fn advance_to_economic(ctx: Context<social_vote::AdvanceToEconomic>) -> Result<()> {
        social_vote::advance_to_economic(ctx)
    }

    pub fn contribute(ctx: Context<contribute::Contribute>, amount_lamports: u64) -> Result<()> {
        contribute::handler(ctx, amount_lamports)
    }

    pub fn finalize_funding(ctx: Context<finalize_funding::FinalizeFunding>) -> Result<()> {
        finalize_funding::handler(ctx)
    }

    pub fn refund(ctx: Context<refund::Refund>) -> Result<()> {
        refund::handler(ctx)
    }

    // ── Actividad del dev ─────────────────────────────────────
    pub fn register_dev_activity(ctx: Context<dev_activity::RegisterDevActivity>) -> Result<()> {
        dev_activity::handler(ctx)
    }

    pub fn trigger_inactivity(ctx: Context<dev_activity::TriggerInactivity>) -> Result<()> {
        dev_activity::trigger_inactivity(ctx)
    }
}
