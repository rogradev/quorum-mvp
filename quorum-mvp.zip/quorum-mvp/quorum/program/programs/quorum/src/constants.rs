// ============================================================
// QUORUM PROTOCOL — CONSTANTS
// ============================================================

/// Fee que retiene la plataforma sobre el total recaudado (0.1%)
pub const PLATFORM_FEE_BPS: u64 = 10; // basis points: 10 = 0.1%

/// Máximo % de supply que puede tener un holder durante vesting (0.1%)
pub const MAX_HOLDER_BPS: u64 = 10; // 10 basis points = 0.1%

/// Mínimo de holders requeridos para que el proyecto avance
pub const MIN_HOLDERS: u64 = 1_000;

/// Mínimo de recaudación en lamports equivalente a $100 USD
/// Asumiendo SOL ~$150 USD → $100 = ~0.667 SOL = 666_666_667 lamports
/// Ajustar según precio real de SOL al deployar
pub const MIN_RAISE_LAMPORTS: u64 = 666_666_667;

/// Duración del vesting en segundos (9 meses = 270 días)
pub const VESTING_DURATION_SECS: i64 = 270 * 24 * 60 * 60;

/// Duración de la fase de votación social en segundos (7 días)
pub const SOCIAL_VOTE_DURATION_SECS: i64 = 7 * 24 * 60 * 60;

/// Duración de la fase de contribución económica en segundos (14 días)
pub const ECONOMIC_PHASE_DURATION_SECS: i64 = 14 * 24 * 60 * 60;

/// Supply total del token (1 billón con 6 decimales)
pub const TOKEN_SUPPLY: u64 = 1_000_000_000_000_000; // 1B tokens × 10^6

/// Decimales del token
pub const TOKEN_DECIMALS: u8 = 6;

/// Semilla PDA del estado global de la plataforma
pub const PLATFORM_SEED: &[u8] = b"platform";

/// Semilla PDA de cada proyecto
pub const PROJECT_SEED: &[u8] = b"project";

/// Semilla PDA de cada contribución
pub const CONTRIBUTION_SEED: &[u8] = b"contribution";

/// Semilla PDA del vesting del dev
pub const DEV_VESTING_SEED: &[u8] = b"dev_vesting";

/// Semilla PDA del vesting del holder
pub const HOLDER_VESTING_SEED: &[u8] = b"holder_vesting";

/// Semilla PDA del voto social
pub const VOTE_SEED: &[u8] = b"vote";

/// Días de inactividad del dev antes de alerta (en segundos)
pub const INACTIVITY_ALERT_SECS: i64 = 30 * 24 * 60 * 60;

/// Días de inactividad antes de bloqueo (en segundos)
pub const INACTIVITY_LOCK_SECS: i64 = 60 * 24 * 60 * 60;
