use anchor_lang::prelude::*;

/// Estados del ciclo de vida de un proyecto
#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq, InitSpace)]
pub enum ProjectState {
    /// Fase 1 activa: votación social
    SocialVoting,
    /// Fase 2 activa: contribuciones económicas
    EconomicPhase,
    /// Fondeo exitoso, vesting activo
    Vesting,
    /// Fondeo fallido, disponible para reembolso
    Failed,
    /// Vesting completado, proyecto graduado
    Graduated,
}

/// Datos principales de un proyecto en Quorum.
#[account]
#[derive(InitSpace)]
pub struct Project {
    /// Wallet del creador del proyecto
    pub dev: Pubkey,

    /// Mint del token SPL creado para este proyecto
    pub token_mint: Pubkey,

    /// ID único del proyecto (índice secuencial)
    pub project_id: u64,

    /// Nombre del proyecto
    #[max_len(64)]
    pub name: String,

    /// Ticker del token (ej: "QRMD")
    #[max_len(10)]
    pub ticker: String,

    /// Descripción de la utilidad del proyecto
    #[max_len(512)]
    pub description: String,

    /// URL del sitio web o repositorio
    #[max_len(128)]
    pub website_url: String,

    /// Estado actual del proyecto
    pub state: ProjectState,

    // ── Fase 1 ─────────────────────────────────────────────
    /// Timestamp de inicio de la votación social
    pub social_vote_start: i64,

    /// Total de votos sociales recibidos
    pub social_votes: u64,

    // ── Fase 2 ─────────────────────────────────────────────
    /// Timestamp de inicio de la fase económica
    pub economic_phase_start: i64,

    /// Meta de recaudación definida por el dev (en lamports)
    pub raise_goal: u64,

    /// Total recaudado hasta el momento (en lamports)
    pub total_raised: u64,

    /// Número de contribuidores únicos
    pub holder_count: u64,

    /// Fee ya cobrada por la plataforma (en lamports)
    pub platform_fee_paid: u64,

    // ── Vesting ────────────────────────────────────────────
    /// Timestamp en que empieza el vesting (cuando se finaliza el fondeo)
    pub vesting_start: i64,

    /// Timestamp en que termina el vesting
    pub vesting_end: i64,

    // ── Inactividad del dev ────────────────────────────────
    /// Último timestamp de actividad registrada del dev
    pub last_dev_activity: i64,

    /// Si el dev está bloqueado por inactividad
    pub dev_locked: bool,

    /// Bump del PDA
    pub bump: u8,
}
